<?php

use common\models\User;
use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */

$this->title = 'Push-уведомления';

?>
<div class="user-push">

    <h1><?= Html::encode($this->title) ?></h1>

    <h3 class="bg-warning">Страница на стадии разработки.</h3>

    <p>Здесь будет находиться функционал для отправки push-уведомлений пользователям.</p>

</div>
