<?php

    echo $message;

?>