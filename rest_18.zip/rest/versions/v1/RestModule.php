<?php
namespace rest\versions\v1;

use yii\base\Module;

class RestModule extends Module
{
}