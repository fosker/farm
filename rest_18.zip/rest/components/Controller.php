<?php

namespace rest\components;


class Controller extends \yii\rest\Controller
{

    public $serializer = 'rest\components\Serializer';

}