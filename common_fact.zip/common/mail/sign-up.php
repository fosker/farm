<?php
/**
 * Created by PhpStorm.
 * User: Андрей
 * Date: 24.09.2015
 * Time: 18:38

 * @var $seminar_title string
 * @var $username string
 * @var $contact string
 * @var $date string
*/

?>

<p>На ваш семинар "<?=$seminar_title;?>" записался новый желающий:</p>
<p>Имя: <?=$username;?></p>
<p>Контактные данные: <?=$contact;?></p>
<p>Желаемое время: <?=$date;?></p>